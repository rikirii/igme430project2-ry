const path = require('path');
const express = require('express');
const compression = require('compression');
const favicon = require('serve-favicon');
const mongoose = require('mongoose');
const expressHandlebars = require('express-handlebars');
const helmet = require('helmet');
const session = require('express-session');
const RedisStore = require('connect-redis').RedisStore;
const redis = require('redis');
require('dotenv').config();

const router = require('./router.js');
const gameSocketSetup = require('./gameSocket.js');

const port = process.env.PORT || process.env.NODE_PORT || 3000;

const dbURI = process.env.MONGODB_URI || 'mongodb://localhost/project2';
mongoose.connect(dbURI).catch((err) => {
    if (err) {
        console.log('Could not connect to database');
        throw err;
    }
});

const redisClient = redis.createClient({
    url: process.env.REDISCLOUD_URL,
});

redisClient.on('error', err => console.log('Redis Client Error', err));

redisClient.connect().then(() => {
    const app = express();

    // helmet is a security library for express: sets a bunch of default options for use to obsure info from malicious attackss
    app.use(helmet());
    app.use('/assets', express.static(path.resolve(`${__dirname}/../hosted`)));
    app.use(favicon(`${__dirname}/../hosted/img/favicon.png`));
    app.use(compression());
    app.use(express.urlencoded({ extended: true }));
    app.use(express.json());

    const sessionMiddle = session({
        key: 'sessionid',
        store: new RedisStore({
            client: redisClient,
        }),
        secret: 'AriThankyou ItsAwesome',
        resave: false,
        saveUninitialized: false,
    });

    app.use(sessionMiddle);

    app.engine('handlebars', expressHandlebars.engine({ defaultLayout: '' }));
    app.set('view engine', 'handlebars');
    app.set('views', `${__dirname}/../views`);

    router(app);
    const server = gameSocketSetup.gameSocketSetup(app, sessionMiddle);

    server.listen(port, (err) => {
        if (err) { throw err; }
        console.log(`Listening on port ${port}`);
    });
})



